<?php

if(isset($_REQUEST['uploadApp']))
{
$error=$_FILES['myfile']['error'];
	if($error!=0)
	{
	echo "<Br />><h3>File not uploaded, it seems the file is not selected or there is some error with the file or the server seems busy, try later.</h3>We will redirect you back to the dashboard. Please wait..<br/>
		If you are not redirected please click <a href='dashboard.php'>here</a>";
	}
	else
	{
	$fname=$_FILES['myfile']['name'];
	$ftype=$_FILES['myfile']['type'];
	$fsize=$_FILES['myfile']['size'];
	$ftname=$_FILES['myfile']['tmp_name'];
	$target="../app/$fname";
	//unlinking file
			$files = glob('../app/*'); // get all file names
				foreach($files as $file){ // iterate files
				  if(is_file($file))
					unlink($file); // delete file
				}
//above code clears the folder
	
	$ans=move_uploaded_file($ftname,$target);
	if($ans)
	{
	//save info to database
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$target=addslashes($target);
		$query="truncate table up_app;";
		mysql_query($query);
		$query="insert into up_app (filename,filetype,filesize,filepath) values ('$fname','$ftype',$fsize,'$target')";
		$n=mysql_query($query);
		if($n==1)
		{
			echo "<Br />File upload successful<br/>";
			$query="select * from up_app ORDER BY fileid DESC LIMIT 1;";
			$rs=mysql_query($query);
			while($rows=mysql_fetch_array($rs))
			{
				echo"$rows[1] Uploaded successfully <br/>We will redirect you back to the dashboard. Please wait..<br/>
				If you are not redirected please click <a href='dashboard.php?count=app'>here</a>";
				
			}
			header('Refresh: 5;url=dashboard.php?count=app');
		}
		else
		{
	echo "<Br /><h3>File not uploaded, server seems busy, try later.</h3>We will redirect you back to the dashboard. Please wait..<br/>
		If you are not redirected please click <a href='dashboard.php?count=app'>here</a>";
		header('Refresh: 5;url=dashboard.php?count=app');
		}
	}
	else
	{
	echo "<Br /><h3>File not uploaded, server seems busy, try later.</h3>We will redirect you back to the dashboard. Please wait..<br/>
		If you are not redirected please click <a href='dashboard.php?count=app'>here</a>";
			header('Refresh: 5;url=dashboard.php?count=app');
	}
	
	}
}
?>