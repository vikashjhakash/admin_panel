$(document).ready(function(){		
		$(document).on('click', '.bton', function(){
			var id= $(this).data("id");
			var page= $(this).data("page");
			if(confirm("Do you want to delete this row"))
			{
				$.ajax({
					url: 'delete.php',
					method: 'POST',
					data:{id:id, table:page},
					success: function(data){
						alert(data);
						location.reload();
					}
				});
			}
		});
		/*This set of code add menus*/
		$(document).on('click','#addMenu', function(){
			var mainMenu= $("#mainMenu").text();
			var sub1= $("#sub1").text();
			var sub2= $("#sub2").text();
			var sub3= $("#sub3").text();
			var sub4= $("#sub4").text();
			var sub5= $("#sub5").text();
			var sub6= $("#sub6").text();
			var sub7= $("#sub7").text();
			$.ajax({
				url:'insert.php',
				method:'POST',
				data: {mainMenu:mainMenu, sub1:sub1, sub2:sub2, sub3:sub3, sub4:sub4, sub5:sub5, sub6:sub6, sub7:sub7, page:'addmenu'},
				success:function(data){
					alert(data);
					location.reload();
				}
			});
		});
		
		/*This set of code add footer menus*/
		$(document).on('click','#addFooter', function(){
			var menu= $("#menu").text();
			var menu_right= $("#menu_right").text();
			$.ajax({
				url:'insert.php',
				method:'POST',
				data: {menu:menu, menu_right:menu_right, page:'addFooter'},
				success:function(data){
					alert(data);
					location.reload();
				}
			});
		});
		
		/*This set of code adds post to database*/
		$(document).on('click','#addPost', function(){
			var pagename= $('#pagename').text();
			var header= $('#header').text();
			var content = CKEDITOR.instances['content'].getData();
			var comment= $('#comment').text();
			$.ajax({
				url:'insert.php',
				method:'POST',
				data: {pagename:pagename, header:header, content:content, comment:comment, page:'addPost'},
				success:function(data){
					alert(data);
					location.reload();
				}
			});
		});
		
		
			/*This set of code adds post to database*/
		$(document).on('click','#updateWelcomeMsg', function(){
			var content = CKEDITOR.instances['body'].getData();
			$.ajax({
				url:'insert.php',
				method:'POST',
				data: {content:content, page:'updateWelcomeMsg'},
				success:function(data){
					alert(data);
					location.reload();
				}
			});
		});
		
		/*This set of code adds user to database*/
		$(document).on('click','#addUser', function(){
			var uid= ($("#uid").text()).concat('@cts.com');
			var coupon = Math.floor((Math.random() * 999999999) + 1);
			$.ajax({
				url:'insert.php',
				method:'POST',
				data: {uid:uid, coupon:coupon, page:'addUser'},
				success:function(data){
					alert(data);
					location.reload();
				}
			});
		});
		
		/*This set of code adds Admin to database*/
		$(document).on('click','#addAdmin', function(){
			var uid= ($("#uid").text()).concat('@cts.com');
			var coupon = Math.floor((Math.random() * 999999999) + 1);
			$.ajax({
				url:'insert.php',
				method:'POST',
				data: {uid:uid, coupon:coupon, page:'addAdmin'},
				success:function(data){
					alert(data);
					location.reload();
				}
			});
		});
		
		
		/*This set of code adds sidenav to database*/
		$(document).on('click','#addsidenav', function(){
			var pagename= $("#pagename").text();
			var nav= $("#nav").text();
			var description = CKEDITOR.instances['description'].getData();
			var active= $("#active").text();
			if(active==null || active=="")
			{
				active='false';
			}
			$.ajax({
				url:'insert.php',
				method:'POST',
				data: {pagename:pagename, nav:nav, description:description, active:active, page:'addsidenav'},
				success:function(data){
					alert(data);
					location.reload();
				}
			});
		});
		
		
		
		/*this set of code update data*/
		$(document).on('blur','.type', function(){
				var page = $(this).data("page");
				var colName= $(this).data("col");
				var updatedData= $(this).text();
				var sno= $(this).data("id");
				$.ajax({
					url:'update.php',
					method: 'POST',
					data:{sno:sno, colName:colName, data:updatedData, page:page},
					success: function(data){
						alert(data);
						location.reload();
					}
				});	
			
		});
		
		$(document).on('click','#introDataUpload', function(){
			var pagename = $("#pagename").val();
			var title = CKEDITOR.instances['body'].getData();
			var form_data = new FormData();
			var file_data = $('#file').get(0).files[0];
			form_data.append('file', file_data);
			form_data.append('pagename', pagename);
			form_data.append('title', title);
			$.ajax({
						url: 'introDataUpload.php', // point to server-side PHP script 
						dataType: 'text',  // what to expect back from the PHP script, if anything
						cache: false,
						contentType: false,
						processData: false,
						data: form_data,                         
						method: 'POST',
						success: function(data){
						alert(data);
						location.reload();
					}

			 });
		});
		
		
		
		$(document).on('click','#RMPData', function(){
			var pagename = $("#pagename").val();
			var header = $("#header").val();
			var title = CKEDITOR.instances['body'].getData();
			var form_data = new FormData();
			var file_data = $('#file').get(0).files[0];
			form_data.append('file', file_data);
			form_data.append('pagename', pagename);
			form_data.append('header', header);
			form_data.append('title', title);
			$.ajax({
						url: 'readmorepostdataupload.php', // point to server-side PHP script 
						//dataType: 'text',  // what to expect back from the PHP script, if anything
						cache: false,
						contentType: false,
						processData: false,
						data: form_data,                         
						method: 'POST',
						success: function(data){
						alert(data);
						location.reload();
					}

			 });
		});
		
		
		$(document).on('click','#assetsDataUpload', function(){
			var pagename = $("#pagename").val();
			var page = 'assets';
			var asset_name = $("#asset_name").val();
			var asset_content = CKEDITOR.instances['asset_content'].getData();
			var asset_link = $("#asset_link").val();
			var form_data = new FormData();
			var file_data = $('#file').get(0).files[0];
			form_data.append('file', file_data);
			form_data.append('pagename', pagename);
			form_data.append('asset_name', asset_name);
			form_data.append('asset_link', asset_link);
			form_data.append('asset_content', asset_content);
			form_data.append('page', page);
			$.ajax({
						url: 'insert.php', // point to server-side PHP script 
						//dataType: 'text',  // what to expect back from the PHP script, if anything
						cache: false,
						contentType: false,
						processData: false,
						data: form_data,                         
						method: 'POST',
						success: function(data){
						alert(data);
						location.reload();
					}

			 });
		});
		
		
		$(document).on('click','#modalMenu', function(){
			var pagename = $("#pagename").val();
			var page = 'modalMenu';
			var menuname = $("#menuname").val();
			var nav = $("#nav").val();
			var content = CKEDITOR.instances['content'].getData();
			var form_data = new FormData();
			var file_data = $('#file').get(0).files[0];
			form_data.append('file', file_data);
			form_data.append('pagename', pagename);
			form_data.append('menuname', menuname);
			form_data.append('content', content);
			form_data.append('nav', nav);
			form_data.append('page', page);
			$.ajax({
						url: 'insert.php', // point to server-side PHP script 
						//dataType: 'text',  // what to expect back from the PHP script, if anything
						cache: false,
						contentType: false,
						processData: false,
						data: form_data,                         
						method: 'POST',
						success: function(data){
						alert(data);
						location.reload();
					}

			 });
		});
		
		
});