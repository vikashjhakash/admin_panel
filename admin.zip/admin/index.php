<?php
header('Refresh: .1;url=dashboard.php?count=home') or die();

?>