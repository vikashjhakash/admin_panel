<?php

if(isset($_REQUEST['uploadMarquueeData']))
{
$pagename=$_POST['pagename'];
$title=$_POST['title'];
	
$error=$_FILES['myfile']['error'];
	if($error!=0)
	{
	echo "<Br />><h3>File not uploaded, it seems the file is not selected or there is some error with the file or the server seems busy, try later.</h3>We will redirect you back to the dashboard. Please wait..<br/>
		If you are not redirected please click <a href='dashboard.php'>here</a>";
	}
	else
	{
	$fname=$_FILES['myfile']['name'];
	$ftype=$_FILES['myfile']['type'];
	$fsize=$_FILES['myfile']['size'];
	$ftname=$_FILES['myfile']['tmp_name'];
	$target="../marquee/$fname";
	
	$ans=move_uploaded_file($ftname,$target);
	if($ans)
	{
	//save info to database
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$target=addslashes($target);
		
		$query="insert into marquee (pagename,filetype,filesize,title,link) values ('$pagename','$ftype',$fsize,'$title','$target')";
		$n=mysql_query($query);
		
		if($n==1)
		{
			echo "<Br />File upload successful<br/>";
			$query="select * from marquee ORDER BY sno DESC LIMIT 1;";
			$rs=mysql_query($query);
			while($rows=mysql_fetch_array($rs))
			{
				echo"$rows[1] Uploaded successfully <br/>We will redirect you back to the dashboard. Please wait..<br/>
				If you are not redirected please click <a href='dashboard.php?count=marquee'>here</a>";
				
			}
			header('Refresh: 5;url=dashboard.php?count=marquee');
		}
		else
		{
	echo "<Br /><h3>File not uploaded, server seems busy, try later.</h3>We will redirect you back to the dashboard. Please wait..<br/>
		If you are not redirected please click <a href='dashboard.php?count=marquee'>here</a>";
		header('Refresh: 5;url=dashboard.php?count=marquee');
		}
	}
	else
	{
	echo "<Br /><h3>File not uploaded, server seems busy, try later.</h3>We will redirect you back to the dashboard. Please wait..<br/>
		If you are not redirected please click <a href='dashboard.php?count=marquee'>here</a>";
			header('Refresh: 5;url=dashboard.php?count=marquee');
	}
	
	}
}
?>