<?php
/*This file is used to inserting data to table, please make sure that the database name, host name, username, password, table name, and column names are as per mentioned in the codes*/
$pageName=$_POST['page'];
if($pageName=='addmenu'){
$mainMenu=$_POST['mainMenu'];
$sub1=$_POST['sub1'];
$sub2=$_POST['sub2'];
$sub3=$_POST['sub3'];
$sub4=$_POST['sub4'];
$sub5=$_POST['sub5'];
$sub6=$_POST['sub6'];
$sub7=$_POST['sub7'];
$con=mysql_connect("localhost","root","");
mysql_select_db("rcg_db",$con) or die (mysql_error());
$query="INSERT INTO `menu`(`mainMenu`, `sub1`, `sub2`, `sub3`, `sub4`, `sub5`, `sub6`, `sub7`) VALUES ('$mainMenu','$sub1','$sub2','$sub3','$sub4','$sub5','$sub6','$sub7');";
if(mysql_query($query))
{
	echo"Menus Added! Please wait while the page gets reloaded with updated data.";
}
}else if($pageName=='addPost'){
	$pagename= $_POST['pagename'];
	$header= $_POST['header'];
	$content= $_POST['content'];
	$comment=$_POST['comment'];
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="INSERT INTO `post`(`pagename`, `header`, `content`, `comment`) VALUES ('$pagename','$header','$content','$comment');";
	if(mysql_query($query))
	{
		echo"Post Added! Please wait while the page gets reloaded with updated data.";
	}
}


else if($pageName=='addUser'){
	$uid= $_POST['uid'];
	$coupon=$_POST['coupon'];
	$user=$_COOKIE['first_name'];
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="INSERT INTO `userallowed`(`uid`, `coupon`, `addedBy`) VALUES ('$uid','$coupon','$user');";
	if(mysql_query($query))
	{
		echo"User Added!  The coupon code for User id: $uid is $coupon. Please wait while the page gets reloaded with updated data.";
	}else
		echo"User cannot be added to the database. It might be due to one of the following reasons : User is already added. Database do not respond. The connectivity has some issues. Un-acceptable data for database";
}


else if($pageName=='addAdmin'){
	$uid= $_POST['uid'];
	$coupon=$_POST['coupon'];
	$user=$_COOKIE['first_name'];
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="INSERT INTO `adminUser`(`uid`, `coupon`, `addedBy`) VALUES ('$uid','$coupon','$user');";
	if(mysql_query($query))
	{
		echo"User - $uid is added as Admin to the site. Please ask the user to login to the portal after few minutes and select 'Admin Dashboard after login' Please wait while the page gets reloaded with updated data.";
	}else
		echo"Admin cannot be added to the database. It might be due to one of the following reasons : <br/>User is already added. Database do not respond. The connectivity has some issues. Un-acceptable data for database";
}

else if($pageName=='addFooter'){
	$menu= $_POST['menu'];
	$menu_right=$_POST['menu_right'];
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="INSERT INTO `footer`(`menu`, `menu_right`) VALUES ('$menu','$menu_right');";
	if(mysql_query($query))
	{
		echo"Footer Added! Please wait while the page gets reloaded with updated data.";
	}
}

else if($pageName=='updateWelcomeMsg'){
	$content=$_POST['content'];
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	mysql_query("TRUNCATE TABLE `welcome`;");
	$query="INSERT INTO `welcome`(`body`) VALUES ('$content');";
	if(mysql_query($query))
	{
		echo"Welcome Message Added! Please wait while the page gets reloaded with updated data.";
	}
}

else if($pageName=='addsidenav'){
	$pagename=$_POST['pagename'];
	$nav=$_POST['nav'];
	$description=$_POST['description'];
	$active=$_POST['active'];
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="INSERT INTO `sidnav`(`pagename`, `nav`, `description`, `active`) VALUES ('$pagename','$nav','$description', '$active' );";
	if(mysql_query($query))
	{
		echo"Side Navigation Added! Please wait while the page gets reloaded with updated data.";
	}
}

else if($pageName=='post_read_more'){

$pname=$_POST['pname'];
$content=$_POST['content'];
$header=$_POST['header'];
$error=$_FILES['file']['error'];
	if($error!=0)
	{
	echo "File not uploaded, it seems the file is not selected or there is some error with the file or the server seems busy, try later.
	We will redirect you back to the dashboard. Please wait..";
	}
	else
	{
	$fname=$_FILES['file']['name'];
	$ftype=$_FILES['file']['type'];
	$fsize=$_FILES['file']['size'];
	$ftname=$_FILES['file']['tmp_name'];
	$target="../ReadMore/$fname";
	
	$ans=move_uploaded_file($ftname,$target);
	if($ans)
	{
	//save info to database
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$target=addslashes($target);
		
		$query="insert into `post_read_more` (pagename,header,text,link) values ('$pagename','$header',$content,'$target')";
		$n=mysql_query($query);
		
		if($n==1)
		{
			echo "File upload successful";
			
		}
		else
		{
		echo "File not uploaded, server seems busy, try later. We will redirect you back to the dashboard. Please wait..";
		
		}
	}
	else
	{
	echo "File not uploaded, server seems busy, try later. We will redirect you back to the dashboard. Please wait.";
			
	}
	
	}


}


else if($pageName=='assets'){

$pagename=$_POST['pagename'];
$asset_name=$_POST['asset_name'];
$asset_link=$_POST['asset_link'];
$asset_content=$_POST['asset_content'];
	
$error=$_FILES['file']['error'];
	if($error!=0)
	{
	echo "File not uploaded, it seems the file is not selected or there is some error with the file or the server seems busy, try later.
	We will redirect you back to the dashboard. Please wait..";
	}
	else
	{
	$fname=$_FILES['file']['name'];
	$ftype=$_FILES['file']['type'];
	$fsize=$_FILES['file']['size'];
	$ftname=$_FILES['file']['tmp_name'];
	$target="../assets/$fname";
	
	$ans=move_uploaded_file($ftname,$target);
	if($ans)
	{
	//save info to database
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$target=addslashes($target);
		
		$query="INSERT INTO `assets`(`pagename`, `asset_name`, `asset_image`, `asset_content`, `link`) VALUES ('$pagename','$asset_name','$target','$asset_content' ,'$asset_link');";
		$n=mysql_query($query);
		
		if($n==1)
		{
			echo "File upload successful! Data is added. Please wait while page reloads";
			
		}
		else
		{
		echo "File not uploaded, server seems busy, try later. We will redirect you back to the dashboard. Please wait..";
		
		}
	}
	else
	{
	echo "File not uploaded, server seems busy, try later. We will redirect you back to the dashboard. Please wait.";
			
	}
	
	}

}




else if($pageName=='modalMenu'){

$pagename=$_POST['pagename'];
$menuname=$_POST['menuname'];
$nav=$_POST['nav'];
$content=$_POST['content'];

$error=$_FILES['file']['error'];
	if($error!=0)
	{
	echo "File not uploaded, it seems the file is not selected or there is some error with the file or the server seems busy, try later.
	We will redirect you back to the dashboard. Please wait..";
	}
	else
	{
	$fname=$_FILES['file']['name'];
	$ftype=$_FILES['file']['type'];
	$fsize=$_FILES['file']['size'];
	$ftname=$_FILES['file']['tmp_name'];
	$target="../modalMenuDocs/$fname";
	
	$ans=move_uploaded_file($ftname,$target);
	if($ans)
	{
	//save info to database
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$target=addslashes($target);
		
		$query="INSERT INTO `modalmenu`( `pagename`, `nav`, `menuname`, `content`, `readmore`) VALUES ('$pagename','$nav','$menuname','$content' ,'$target');";
		$n=mysql_query($query);
		
		if($n==1)
		{
			echo "File upload successful! Data is added. Please wait while page reloads";
			
		}
		else
		{
		echo "File not uploaded, server seems busy, try later. We will redirect you back to the dashboard. Please wait..";
		
		}
	}
	else
	{
	echo "File not uploaded, server seems busy, try later. We will redirect you back to the dashboard. Please wait.";
			
	}
	
	}

}





?>