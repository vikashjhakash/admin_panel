
<div contenteditable="true" class="container">
	<div contenteditable="true" class="row" style="background:#fff; padding:0px; //opacity:.8">
		<div contenteditable="true" class="col-sm-12" style="padding:5px">
			<div contenteditable="true" class="col-sm-12" style="//padding:px; padding-top:0px;">
				<br/>
					<div contenteditable="true" class="col-sm-6" style="border:1px solid #eee; box-shadow: 5px 5px 5px #eee; background:#f2f2f2; padding: 5px;">
					<p>
					In today&rsquo;s Industry, Customers are moving towards the&nbsp;<strong>Industry Standard packages Solutions&nbsp;</strong>that are easier for maintenance and upgrade. As more focus is towards the Upgrade and Migration rather than new implementation, the packages that support and integrates with their existing system/application have become more popular. Majority of the customers prefer implementing cloud based packages such as <strong>Demandware, Sterling, SAP Hana, Raymark, mPOS </strong>and other mobile enabled packages for their business need.</p>
					<p>As always, Cognizant views this change as an opportunity to embrace the new and emerge as the market leader. <strong>Cognizant RCG QEA is collaborating with the Retail Enterprise Service Group</strong> on a number of strategic initiatives to leap frog the competition and bring value to the customers.</p>
					<p><strong  style="color:#004d80;">Why are Products &amp; Packages Dominating the New World?</strong></p>
					<p>In this era of ever fleeting business opportunities, organizations with agility and accelerated time-to-revenue yield profit and power in the market. At the same time, to have a competitive edge, the business operations need to run as efficiently as possible without compromising customer satisfaction and experience.</p>
					<p>A compact product if used properly can help a business to grow like anything:-</p>
					<ul style="color:#009933;">
					<li>Faster time to market.</li>
					<li>More Robust and scalable than organization specific in-house products.</li>
					<li>More compact solution and chance of error is minimized to 0.</li>
					<li>Decrease in cost by enhancing automation.</li>
					</ul>
					
					</div>
					
					<div contenteditable="true" class="col-sm-6">
						<img src="images/imagesForWebsite/handShakeImage.png" class="img-responsive" style="max-height:300px; margin:auto auto;"/><br/>
						<img src="images/post82.png" class="img-responsive" style="max-height:300px; margin:auto auto;"/>
					
					</div>
					
					
					<img src="images/line.png" class="img-responsive" style="margin:auto; "/>
					
					<div contenteditable="true" class="col-sm-7" style="border:1px solid #eee; border-radius:1px 35px 1px 35px; box-shadow:3px 2px 5px 3px #00bfff; background:#f2f2f2; padding: 15px;">
						<strong>Cognizant&rsquo;s</strong>&nbsp;RCG QE&amp;A practice caters to various quality engineering and assurance needs of clients in the Retail &amp; Consumer goods space. Cognizant&rsquo;s core strength lies in the deep Domain knowledge, core product understanding &amp; skill enablement to address the market needs. Cognizant has a global footprint, working with leading Retailers and CG companies around the World with&nbsp;<strong>~50 accounts</strong>.</p>
						<p>Cognizant has strong experience on Full spectrum services around Retail products &amp; packages which includes primarily packages like&nbsp;<strong>Oracle, Sterling, JDA, Red Prairie, and Manhattan etc.&nbsp;</strong>Cognizant has Strategic partnerships &amp; Industry alliances - <strong>Oracle Platinum Partner, Manhattan &amp; JDA platinum partner, Sterling&rsquo;s alliance partner, premier level partnership with IBM. </strong>Cognizant QE&amp;A has in-depth knowledge across Retail &amp; CG Value chain in domain from<strong>&nbsp;Supply Chain Management, Merchandising &amp; Planning, Store Operations, Multi-channel, Order Management &amp; Enterprise Applications.</strong></p>
					</div>
					
					<div contenteditable="true" class="col-sm-5">
						<img src="images/rcgHomeImage.png" class="img-responsive" style="max-height:300px;padding:5px; margin:auto auto;"/>
					</div>
					</div>

							<img src="images/line.png" class="img-responsive" style="margin:auto; "/>
	</div>
</div>
 

</div> 


</div>

 
<div contenteditable="true" class="container" style="background:#fff">
<div contenteditable="true" class="container-fluid" style="background:#97e5ff; border-radius:1px 35px 1px 35px; box-shadow:3px 2px 5px 3px #00bfff; " >

<div contenteditable="true" class="row" >
<div contenteditable="true" class="col-sm-6">

<h5 style="color:#101010"><strong>Moving towards Package solutions</strong></h5>
<ul style="color:#101010">
<li>Customers moving towards Industry standard packaged solutions that are easier for maintenance and upgrade</li>
<li>Packages that support and integrates with their existing system/application</li>
<li>More focus towards upgrade and migration rather than new implementation.</li>
</ul>
</div>

<div contenteditable="true" class="col-sm-6">
<h5 style="color:#101010"><strong>Dev-Ops and Agile Working</strong></h5>
<ul style="color:#101010">
<li>Moving towards Devops to bring early involvement in overall solution and collaboration with development, support and implementation team</li>
<li>Follow agile methodologies for faster time to market</li></ul>
</div>
</div>

<div contenteditable="true" class="row" >
<div contenteditable="true" class="col-sm-6">
<h5 style="color:#101010"><strong>More focus on Digital Mobility</strong></h5>
<ul style="color:#101010">
<li>More focused on mobile & Digital Strategy</li>
<li>Majority of our customers are moving towards mPOS and other mobile enabled packages</li>
</ul><br/>
<h5 style="color:#101010"><strong>More focus on Automation</strong></h5>
<ul style="color:#101010">
<li>Implement and increase automation across different business areas</li>
<li>Expand automation coverage across various types of testing</li></ul>

</div>


<div contenteditable="true" class="col-sm-6">
<img src="images/Industry Trends.png" class="img-responsive" />
</div>
</div>



</div>

<h2 style="color:#00bfff">Approach to help business</h2>
<div contenteditable="true" class="row">
<!--<div contenteditable="true" class="col-sm-4">
<img src="images/approach.png" class="img-responsive" style="max-weidth:100px; //float:left; margin:auto; padding:10px"/>
</div>-->
<div contenteditable="true" class="col-sm-8">

 Provide <strong>GTM strategy</strong> across Consulting, configuration, testing and implementation with faster time to market,
 Develop Package <strong>testing Competency</strong> for increasing business need on key packages,
 <strong>Knowledge sharing</strong> through mailers , blogs , c2wikis and other platforms,
 Do <strong>demand forecasting of required skills</strong> ,accordingly train associates and do external hiring if needed,
 Develop <strong>automation framework</strong> that suits for different products/package implementation,
 <strong>Build competency</strong> around continuous integration and devops model,
 Revisit <strong>CARTS</strong> to add/update test case suite with latest product feature,
 Leverage <strong>reusable productivity</strong> improvement assets across accounts,
 <strong>Build retail 360 degree view</strong> for each domain area and one E2E retail landscape,
 Collaborate with <strong>Retail enterprise group</strong> for constancy and other Retail package solutions .,
 <strong>Build assessment framework</strong> on the key service offering in Package testing space
 Design case study on focused <strong>package implementations</strong>,

</div>
<div contenteditable="true" class="col-sm-4">
<img src="images/approach2.png" class="img-responsive" style="max-weidth:100px; //float:right;margin:auto; padding:10px"/>
</div></div>
<!--<strong>>> Package implementation/Roll out</strong>

<p><em>&nbsp;#levis-SAP, Raymark, OMS #Costco---JDA WMS,JDA TMS </em></p>
<p><em>#JLP-WCS/ATG/Sterling #Sephora-- Red Prairie WMS, Streling OMS </em></p>
<p><em>#Lulu lemon--Manhattan WMS, Woolworths- Retailix, #Gymboree--Epicor </em></p>-->
<p><strong><em>This portal is designed to serve as a one-stop shop for all product testing needs and references, and more...! Happy browsing!</em></strong></p>			
				
				<!--<div contenteditable="true" class="col-sm-4"><img class="img-responsive" src='images/Cloud_computing.svg.png' /></div>-->
			
		
	
	
	<div contenteditable="true" class="row">
		<div contenteditable="true" class="col-sm-12" style="background:#fff;"> 
		
		<!--<div contenteditable="true" class="container-fluid" style="background:#2ea443">
<h4 style="padding:5px;text-align:center; color:#fff"><strong style="color:#fff">Our Clients</strong></h4>
</div>-->
			
			
				
<div contenteditable="true" class="row">
	<div contenteditable="true" class="col-sm-6" style="border:1px solid #eee">
<img src="images/line.png" class="img-responsive" style="margin:auto;"/>
	<div contenteditable="true" class="row">
<div contenteditable="true" class="container-fluid" style="background:#2ea443">
<h4 style="//padding:px;text-align:center; color:#fff"><strong style="color:#fff">Our Clients</strong></h4>
</div>
</div>
<img src="images/home_logos/logo (1).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (2).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (3).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (4).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (5).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (6).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (7).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (8).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>

<img src="images/home_logos/logo (10).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (11).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>

<img src="images/home_logos/logo (13).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (14).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (15).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>

<img src="images/home_logos/logo (17).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>



<img src="images/home_logos/logo (21).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>


<img src="images/home_logos/logo (24).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (25).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (26).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (27).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>


<img src="images/home_logos/logo (30).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (31).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (32).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>



<img src="images/home_logos/logo (37).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>


<img src="images/home_logos/logo (40).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>



<img src="images/home_logos/logo (44).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (45).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (46).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (47).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (48).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (49).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>

</div>





<div contenteditable="true" class="col-sm-6" style="border:1px solid #eee">
<img src="images/line.png" class="img-responsive" style="margin:auto;"/>


	<div contenteditable="true" class="row">
<div contenteditable="true" class="container-fluid" style="background:#2ea443">
<h4 style="//padding:px;text-align:center; color:#fff"><strong style="color:#fff">Our Products</strong></h4>
</div>
</div>

<img src="images/home_logos/logo (9).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (12).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (16).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (18).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (19).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (20).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (22).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (23).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (28).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (29).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (33).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (34).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (35).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (36).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (38).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (39).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (41).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (42).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/logo (43).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>

<img src="images/home_logos/as (1).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/as (2).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/as (3).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/as (4).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/as (5).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/as (6).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>
<img src="images/home_logos/as (7).jpg" style="float:left; max-width:100px; padding:10px" class="img-responsive"/>


</div>

</div>
				
			
		
		</div>
	</div>
	
	</div>
			
		<div contenteditable="true" class="row">
<div contenteditable="true" class="container-fluid" style="background:#009cd1">
<h4 style="//padding:px;text-align:center; color:#fff"><strong style="color:#fff">Industry Segments and Business Process Areas</strong></h4>
</div>
</div>
<div contenteditable="true" class="row" style="background:#333333; padding:0px; ">
		<div contenteditable="true" class="container-fluid">
			<div contenteditable="true" class="col-sm-2">
				<h5 style="color:#3399ff"><strong>Supply Chain Management</strong></h5>
				
					<small>
					<ul>
						<li><a href="supplyChainManagement.php #IM" style="color:#fff; font-weight:bold; ">Item Management</a></li>
						<li><a href="supplyChainManagement.php #DM" style="color:#fff; font-weight:bold; ">Demand Management</a></li>
						<li><a href="supplyChainManagement.php #S" style="color:#fff; font-weight:bold; ">Sourcing</a></li>
						<li><a href="supplyChainManagement.php #P" style="color:#fff; font-weight:bold; ">Planning</a></li>
						<li><a href="supplyChainManagement.php #O" style="color:#fff; font-weight:bold; ">Order</a></li>
						<li><a href="supplyChainManagement.php #TM" style="color:#fff; font-weight:bold; ">Transportation Management</a></li>
						<li><a href="supplyChainManagement.php #WM" style="color:#fff; font-weight:bold; ">Warehouse Management</a></li>
						<li><a href="supplyChainManagement.php #d" style="color:#fff; font-weight:bold; ">Distribution</a></li>
						<li><a href="supplyChainManagement.php #sca" style="color:#fff; font-weight:bold; ">Supply Chain Analytics</a></li><br/>
					</ul>
					</small>
				
			</div>
		
			<div contenteditable="true" class="col-sm-2">
				<h5 style="color:#3399ff"><strong>Store Operations</strong></h5>
				
					<small>
					<ul>
						<li><a href="storeOperation.php#im"style="color:#fff; font-weight:bold; ">Inventory Management</a></li>
						<li><a href="storeOperation.php#wm" style="color:#fff; font-weight:bold; ">In Store Productivity / Workforce Management</a></li>
						<li><a href="storeOperation.php#pos" style="color:#fff; font-weight:bold; ">Point of Sale / Point of Service</a></li>
						<li><a href="storeOperation.php#clp" style="color:#fff; font-weight:bold; ">Compliance & Loss Prevention</a></li>
						<li><a href="storeOperation.php#ce" style="color:#fff; font-weight:bold; ">Customer Experience</a></li>
						<li><a href="storeOperation.php#rr" style="color:#fff; font-weight:bold; ">Refunds and Returns</a></li>
					</ul>
					</small>
				
			</div>
		
		
		
			<div contenteditable="true" class="col-sm-2">
				<h5 style="color:#3399ff"><strong>Digital Commerce</strong></h5>
					<small>
					<ul>
						<li><a href="multiChannel.php#ec" style="color:#fff; font-weight:bold; ">eCommerce</a></li>
						<li><a href="multiChannel.php#ecs" style="color:#fff; font-weight:bold; ">eCommerce store</a></li>
						<li><a href="multiChannel.php#csm" style="color:#fff; font-weight:bold; ">Customer Service Management</a></li>
						<li><a href="multiChannel.php#pcim" style="color:#fff; font-weight:bold; ">Product Content and Info Management</a></li>
						<li><a href="multiChannel.php#ue" style="color:#fff; font-weight:bold; ">User Experience</a></li>
						<li><a href="multiChannel.php#sm" style="color:#fff; font-weight:bold; ">Social Media</a></li>
						<li><a href="multiChannel.php#omm" style="color:#fff; font-weight:bold; ">Order Management</a></li>
						<li><a href="multiChannel.php#cci" style="color:#fff; font-weight:bold; ">Cross channel integration</a></li>
						<li><a href="multiChannel.php#m" style="color:#fff; font-weight:bold; ">Mobility</a></li><br/>
					</ul>
					</small>
			</div>
			
			<div contenteditable="true" class="col-sm-2">
				<h5 style="color:#3399ff"><strong>Order Management</strong></h5>
					<small>
				<ul>
						<li><a href="orderManagement.php#cco" style="color:#fff; font-weight:bold; ">Capture Customer Order</a></li>
						<li><a href="orderManagement.php#rme" style="color:#fff; font-weight:bold; ">Recognize, Map, and Enrich</a></li>
						<li><a href="orderManagement.php#do" style="color:#fff; font-weight:bold; ">Decompose and Orchestrate</a></li>
						<li><a href="orderManagement.php#gop" style="color:#fff; font-weight:bold; ">Generate Orchestration Plan</a></li>
						<li><a href="orderManagement.php#me" style="color:#fff; font-weight:bold; ">Manage Events</a></li>
						<li><a href="orderManagement.php#uco" style="color:#fff; font-weight:bold; ">Update Customer Order</a></li>
						<li><a href="orderManagement.php#ctt" style="color:#fff; font-weight:bold; ">Create/Update Trouble Tickets</a></li><br/>
						
					</ul>
					</small>
			</div>
			
			
			<div contenteditable="true" class="col-sm-2">
				<h5 style="color:#3399ff"><strong>Merchandise & Planning</strong></h5>
				
					<small>
					<ul>
						<li><a href="merchand&Planning.php#ap" style="color:#fff; font-weight:bold; ">Assortment Planning</a></li>
						<li><a href="merchand&Planning.php#sm" style="color:#fff; font-weight:bold; ">Space Management</a></li>						
						<li><a href="merchand&Planning.php#far" style="color:#fff; font-weight:bold; ">Forecasting, Allocation & Replenishment</a></li>
						<li><a href="merchand&Planning.php#mp" style="color:#fff; font-weight:bold; ">Merchandise Planning</a></li>
						<li><a href="merchand&Planning.php#pp" style="color:#fff; font-weight:bold; ">Pricing & Promotion</a></li>
						<li><a href="merchand&Planning.php#pd" style="color:#fff; font-weight:bold; ">Product Development</a></li>
						<li><a href="merchand&Planning.php#df" style="color:#fff; font-weight:bold; ">Demand Forecasting</a></li><br/>
					</ul>
					</small>
				
			</div>
			
			
			
			
			
			<div contenteditable="true" class="col-sm-2">
				<h5 style="color:#3399ff"><strong>Enterprise Applications</strong></h5>
				
					<small>
					<ul>
						<li><a href="enterpriseApplications.php#clm" style="color:#fff; font-weight:bold; ">Customer Loyalty & Marketing</a></li>
						<li><a href="enterpriseApplications.php#hr" style="color:#fff; font-weight:bold; ">Human Resources</a></li>
						<li><a href="enterpriseApplications.php#fm" style="color:#fff; font-weight:bold; ">Financial Management</a></li>
						<li><a href="enterpriseApplications.php#ei" style="color:#fff; font-weight:bold; ">Enterprise Infrastructure</a></li>
						<li><a href="enterpriseApplications.php#crm" style="color:#fff; font-weight:bold; ">Customer Relationship Management</a></li>
						<li><a href="enterpriseApplications.php#rm" style="color:#fff; font-weight:bold; ">Risk Management</a></li><br/><br/><br/>
					</ul>
					</small>
				
			</div>
		</div>
	</div>
	
	<hr/>
