<?php
$first_name = 'David';
setcookie('first_name',$first_name,time() + (86400 * 7)); // 86400 = 1 day
?>


<!doctype HTML>
<html>
	<head>
		<title>
			Admin Dashboard
		</title>
			<meta charset="UTF-16">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/bootstrap-theme.css">
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
			<script src="js/bootstrap.js"></script>
			<script src="js/npm.js"></script>
			<link href="editor.css" type="text/css" rel="stylesheet"/>
			<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
			<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
			<!--<script src="editor.js"></script>-->
			<script type="text/javascript" src="../ckeditor-ckfinder-integration/ckeditor/ckeditor.js"></script>
			<script type="text/javascript" src="../ckeditor-ckfinder-integration/ckfinder/ckfinder.js"></script>
			<script src="js/custom1.js"></script>
			
	</head>
	
	<body >
		<div class="row">
			<div class="col-sm-1" >
				<div class="sidebar-nav navbar-fixed-right" >
				  <div class="navbar navbar-default" role="navigation">
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
					  <span class="visible-xs navbar-brand">RCG Admin Panel</span>
					</div>
					<div class="navbar-collapse collapse sidebar-navbar-collapse">
					  <ul class="nav navbar-nav" style="background:#4286f4; opacity:.8; color:#fff; font-weight:strong;">
						<li><a style="color:#fff" href="dashboard.php?count=home">RCG Admin Panel</a></li>
						<li><a style="color:#fff" href="dashboard.php?count=home">HOME</a></li>
						<li><a style="color:#fff" href="dashboard.php?count=menus">MENUS</a></li>
						
						<li class="dropdown" >
							<a class="dropdown-toggle" style="color:#fff" data-toggle="dropdown" href="#">Fixed Pages
							<span class="caret"></span></a>
							<ul class="dropdown-menu">
						<li><a style="color:#000" href="dashboard.php?count=homepage">Home Page</a></li>
						<li><a style="color:#000" href="dashboard.php?count=rcg">RCG Page</a></li>
						<li><a style="color:#000" href="dashboard.php?count=competency">Competency Building Page</a></li>
							</ul>
						  </li>
						  
						 <li class="dropdown" >
							<a class="dropdown-toggle" style="color:#fff" data-toggle="dropdown" href="#">POST
							<span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a style="color:#000" href="dashboard.php?count=intro">POSTS - Intro</a></li>
								<li><a style="color:#000" href="dashboard.php?count=posts">POSTS - Body</a></li>
								<li><a style="color:#000" href="dashboard.php?count=readMorePosts">POSTS - Read More</a></li>
								<li><a style="color:#000" href="dashboard.php?count=postredirects">POSTS - Redirect</a></li>
							</ul>
						  </li>
						
						<li><a style="color:#fff" href="dashboard.php?count=welcomeMsg">WELCOME MESSAGE</a></li>
						
						<li><a style="color:#fff" href="dashboard.php?count=footer">FOOTER</a></li>
						<li><a style="color:#fff" href="dashboard.php?count=uploadLogo">WEBSITE LOGO</a></li>
						<li><a style="color:#fff" href="dashboard.php?count=sideNav">SIDE NAV</a></li>
						<li><a style="color:#fff" href="dashboard.php?count=modalMenu">MODAL DATA</a></li>
						<li><a style="color:#fff" href="dashboard.php?count=ourAsset">OUR ASSETS</a></li>
						<li><a style="color:#fff" href="dashboard.php?count=marquee">MARQUEE</a></li>
						<li><a style="color:#fff" href="dashboard.php?count=stats">STATISTICS</a></li>
						<li><a style="color:#fff" href="dashboard.php?count=app">APP</a></li>
						 <li class="dropdown" >
							<a class="dropdown-toggle" style="color:#fff" data-toggle="dropdown" href="#">ADD UP
							<span class="caret"></span></a>
							<ul class="dropdown-menu">
						
						<li><a style="color:#000" href="dashboard.php?count=addAdmin">ADD ADMIN</a></li>
						<li><a style="color:#000" href="dashboard.php?count=addPeople">ADD PEOPLE</a></li>
						</ul>
						  </li>
					  </ul>
					</div><!--/.nav-collapse -->
				  </div>
				</div>
			</div>
			
			<div class="col-sm-10 " >
				<div style="padding:10px 0 10px 35px; border:#eee 1px solid;">
					<div class="container">
				
					<span id="load" name="load" ></span>
						
					</div>
				</div>
			</div>
		</div>
	</body>
</html>

<?php
	if(isset($_GET['count'])){
		$menuCount= $_GET['count'];
		if ($menuCount=='home' || $menuCount==""){
			?>
				<script>
					$(document).ready(function(){
						var counting='home';
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='menus'){
			?>
				<script>
					$(document).ready(function(){
						var counting=2;
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='posts'){
			?>
				<script>
					$(document).ready(function(){
						var counting=3;
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='addPeople'){
			?>
				<script>
					$(document).ready(function(){
						var counting=5;
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='footer'){
			?>
				<script>
					$(document).ready(function(){
						var counting=6;
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='stats'){
			?>
				<script>
					$(document).ready(function(){
						var counting=14;
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='welcomeMsg'){
			?>
				<script>
					$(document).ready(function(){
						var counting='welcomeMsg';
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='addAdmin'){
			?>
				<script>
					$(document).ready(function(){
						var counting='addAdmin';
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='sideNav'){
			?>
				<script>
					$(document).ready(function(){
						var counting='sideNav';
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='uploadLogo'){
			?>
				<script>
					$(document).ready(function(){
						var counting='uploadLogo';
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='app'){
			?>
				<script>
					$(document).ready(function(){
						var counting='uploadApp';
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='marquee'){
			?>
				<script>
					$(document).ready(function(){
						var counting='marquee';
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='headerImage'){
			?>
				<script>
					$(document).ready(function(){
						var counting='headerImage';
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='intro'){
			?>
				<script>
					$(document).ready(function(){
						var counting='intro';
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='ourAsset'){
			?>
				<script>
					$(document).ready(function(){
						var counting='ourAsset';
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		
		else if ($menuCount=='readMorePosts'){
			?>
				<script>
					$(document).ready(function(){
						var counting='readMorePosts';
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
		else if ($menuCount=='modalMenu'){
			?>
				<script>
					$(document).ready(function(){
						var counting='modalMenu';
						$.ajax({
							url:'select.php',
							method:'POST',
							data: {count:counting},
							success:function(data){
								$("#load").html(data);
							}
						});
					});
				</script>
			<?php
		}
		
	}
?>

