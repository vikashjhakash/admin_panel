<?php
if(isset($_POST['count'])!=null){
$count=$_POST['count'];

/*This section is used to display and update Menus of website*/
if($count=='home'){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM adminuser  ORDER BY sno DESC LIMIT 5;";

	$rs=mysql_query($query);

	$comment="";
	$comment .="	<h3 style='text-align:center; color:#ff9900;'>Welcome to the Admin Panel of RCG - PRODUCT QE&A PORTAL</h3>
	<hr/>
			<div class='row'>
				<div class='col-sm-3'>
					<h4 style='text-align:center; color:#ce2557;'>Our Admin Users</h4>
			";
	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
					<span style='color:#ff6d06' class='glyphicon glyphicon-ok'></span><span style='font-weight:bold'> $rows[1]</span><br/>
			";
			
		}
		
	$comment .="
			<div style='text-align:right'><a href='dashboard.php?count=addAdmin' class='btn btn-warning btn-sm'>Add / Edit</a></div>
			</div>";
	}
	
	$query="SELECT * FROM userallowed ORDER BY sno DESC LIMIT 5;";

	$rs=mysql_query($query);
	$comment .="	
				<div class='col-sm-3'>
					<h4 style='text-align:center; color:#ce2557;'>Allowed D+ Access</h4>
			";
	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
					<span style='color:#ff6d06' class='glyphicon glyphicon-ok'></span><span style='font-weight:bold'> $rows[1]</span><br/>
			";
			
		}
		
	$comment .="
			<div style='text-align:right'><a href='dashboard.php?count=addPeople' class='btn btn-warning btn-sm'>Add / Edit</a></div>
			</div>";
	}
	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("counter",$con) or die (mysql_error());
	$query="SELECT * FROM `user_data` ORDER BY sno DESC LIMIT 5;";

	$rs=mysql_query($query);
	$comment .="	
				<div class='col-sm-3'>
					<h4 style='text-align:center; color:#ce2557;'>Recent Unique Visitors</h4>
			";
	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
					<span style='color:#ff6d06' class='glyphicon glyphicon-user'></span><span style='font-weight:bold'> $rows[1]</span><br/>
			";
			
		}
		
	$comment .="
			<div style='text-align:right'><a href='dashboard.php?count=stats' class='btn btn-warning btn-sm'>Know Nore</a></div>
			</div>";
	}
	
	$query="SELECT * FROM `user_data` ORDER BY sno DESC LIMIT 1;";
	$rs=mysql_query($query);
	$comment .="	
				<div class='col-sm-3'>
					<h4 style='text-align:center; color:#ce2557;'>Visitors Count</h4>
			";
	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
					<span style='color:#ff6d06' class='glyphicon glyphicon-user'></span> Total Unique Visitors<span style='font-weight:bold; color: #ff6d06' >  $rows[0]</span><br/>
			";
			
		}
	}
	
	
	$query="SELECT * FROM `counter_table`;";
	$rs=mysql_query($query);
	
	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
					<span style='color:#ff6d06' class='glyphicon glyphicon-user'></span> Total Login<span style='font-weight:bold; color: #ff6d06' >  $rows[1]</span><br/>
			";
			
		}
		
	$comment .="
			<div style='text-align:right'><a href='dashboard.php?count=stats' class='btn btn-warning btn-sm'>Know Nore</a></div>
			</div></div>";
	}
	
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM up_app ;";

	$rs=mysql_query($query);
	$comment .="<hr/>
			<div class='row'>
				<div class='col-sm-4'>
					<h4 style='text-align:center; color:#ce2557;'>RCG APP</h4>
			";
	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
					<span style='color:#ff6d06' class='	glyphicon glyphicon-folder-close'></span> App Name & Version<span style='font-weight:bold'> $rows[1]</span><br/>
					<span style='color:#ff6d06' class='glyphicon glyphicon-ok'></span> App Size<span style='font-weight:bold'> $rows[1]</span><br/>
			";
			
		}
		
	$comment .="
			<div style='text-align:right'><br/><a href='dashboard.php?count=app' class='btn btn-warning btn-sm'>Add / Edit</a></div>
			<hr/>
			<div style='text-align:justify'>
			<h4 style='text-align:center; color:#ce2557;'>Some Important Points to NOTE</h4>
			<span style='color:#ff6d06' class='glyphicon glyphicon-copy'></span><span style='font-weight:italic'> You are one of the Admins and can add / edit data on the website</span><br/>
			<span style='color:#ff6d06' class='glyphicon glyphicon-copy'></span><span style='font-weight:italic'> Please do changes at time when the traffic on the website is low</span><br/>
			<span style='color:#ff6d06' class='glyphicon glyphicon-copy'></span><span style='font-weight:italic'> We recommend you to type the entire post inside the website and while adding and deleting please wait till the website loads completely</span><br/>
			<span style='color:#ff6d06' class='glyphicon glyphicon-copy'></span><span style='font-weight:italic'> Upload the APK file in the App upload section. When you upload new App the earlier version will be auto removed</span><br/>
			<span style='color:#ff6d06' class='glyphicon glyphicon-copy'></span><span style='font-weight:italic'> The LOGO uploaded in the Logo-upload section will be reflected as the website logo throughout the website</span><br/>
			<span style='color:#ff6d06' class='glyphicon glyphicon-copy'></span><span style='font-weight:italic'> The menu added will be displayed in the website throughout.</span><br/>
			<span style='color:#ff6d06' class='glyphicon glyphicon-copy'></span><span style='font-weight:italic'> The bottom-nav added will be displayed in the website throughout.</span><br/>
			<span style='color:#ff6d06' class='glyphicon glyphicon-copy'></span><span style='font-weight:italic'> The changes made from this Admin-panel will be reflected immediately</span><br/>
			<span style='color:#ff6d06' class='glyphicon glyphicon-copy'></span><span style='font-weight:italic'> We are keeping track of people you add for the D+ access and to the Admin access due to security reasons</span><br/>
			<span style='color:#ff6d06' class='glyphicon glyphicon-copy'></span><span style='font-weight:italic'> We are keeping track of your login and logout details due to security reasons</span><br/>
			<span style='color:#ff6d06' class='glyphicon glyphicon-copy'></span><span style='font-weight:italic'> Do not forget to LOGOUT from this panel once you have updated the required data. As we have kept the session time long enough for you to type the entire post directly in the website without getting logged off</span><br/>
			</div>
			</div>";
	}
	
	
	
	$query="SELECT * FROM welcome;";
	$rs=mysql_query($query);
	$comment .="
				<div class='col-sm-8'>
					<h4 style='text-align:center; color:#ce2557;'>Current Welcome Page</h4>
					<hr/>
			";
	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
					 $rows[1]
			";
			
		}
		
	$comment .="<hr/>
			<div style='text-align:right'><br/><a href='dashboard.php?count=welcomeMsg' class='btn btn-warning btn-sm'>Update</a></div>
			</div>";
	}

echo $comment;
}



/*This section is used to display and update Menus of website*/
if($count==2){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM menu;";

	$rs=mysql_query($query);

	$comment="";
	$comment .="
	<div class='table-responsive' >
	<p style='text-align:center; color:#33adff; font-weight:bold'>Here you can Add, Update or Delete Menus and Sub-Menus which will be displayed on the website</p>
	<br/>
	<table class='table-bordered table' >
	<tr style='background:#eee'>
						<th>Menu</th>
						<th>Sub Menu 1</th>
						<th>Sub Menu 2</th>
						<th>Sub Menu 3</th>
						<th>Sub Menu 4</th>
						<th>Sub Menu 5</th>
						<th>Sub Menu 6</th>
						<th>Sub Menu 7</th>
						<th>Delete/Add</th>
	</tr>

	";

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
				
					<tr >
						<td contenteditable data-id2='".$rows[1]."' data-id='".$rows[0]."' data-page='menu' data-col='mainMenu' class='type'>$rows[1]</td>
						<td contenteditable data-id2='".$rows[2]."' data-id='".$rows[0]."' data-page='menu' data-col='sub1' class='type'>$rows[2]</td>
						<td contenteditable data-id2='".$rows[3]."' data-id='".$rows[0]."' data-page='menu' data-col='sub2' class='type'>$rows[3]</td>
						<td contenteditable data-id2='".$rows[4]."' data-id='".$rows[0]."' data-page='menu' data-col='sub3' class='type'>$rows[4]</td>
						<td contenteditable data-id2='".$rows[5]."' data-id='".$rows[0]."' data-page='menu' data-col='sub4' class='type'>$rows[5]</td>
						<td contenteditable data-id2='".$rows[6]."' data-id='".$rows[0]."' data-page='menu' data-col='sub5' class='type'>$rows[6]</td>
						<td contenteditable data-id2='".$rows[7]."' data-id='".$rows[0]."' data-page='menu' data-col='sub6' class='type'>$rows[7]</td>
						<td contenteditable data-id2='".$rows[8]."' data-id='".$rows[0]."' data-page='menu' data-col='sub7' class='type'>$rows[8]</td>
						<td ><button class='btn btn-danger bton' data-id='".$rows[0]."' data-page='menu' >x</button></td>
					</tr>
				
			";
			
		}
		
			$comment .="
				
					<tr>
						
						<td contenteditable id='mainMenu'>$rows[1]</td>
						<td contenteditable id='sub1'>$rows[2]</td>
						<td contenteditable id='sub2'>$rows[3]</td>
						<td contenteditable id='sub3'>$rows[4]</td>
						<td contenteditable id='sub4'>$rows[5]</td>
						<td contenteditable id='sub5'>$rows[6]</td>
						<td contenteditable id='sub6'>$rows[7]</td>
						<td contenteditable id='sub7'>$rows[8]</td>
						<td ><button class='btn btn-success ' id='addMenu' >+</button></td>
					</tr>
				
			";
	}
	else{
		$comment .="
				
					<tr>
						<td colspan='4'>Nothing Found</td>
					</tr>
				
			";
	}

	$comment .="</table></div>";
echo $comment;
}

else if($count==6){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM footer;";

	$rs=mysql_query($query);

	$comment="";
	$comment .="
	<div class='table-responsive' >
	<p style='text-align:center; color:#33adff; font-weight:bold'>Here you can Add, Update or Delete Menus and Sub-Menus which will be displayed on the website</p>
	<br/>
	<table class='table-bordered table' >
	<tr style='background:#eee'>
						<th>Menu Left</th>
						<th>Menu Right</th>
						<th>Delete/Add</th>
	</tr>

	";

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
				
					<tr >
						<td contenteditable data-id2='".$rows[1]."' data-id='".$rows[0]."' data-page='footer' data-col='menu' class='type'>$rows[1]</td>
						<td contenteditable data-id2='".$rows[2]."' data-id='".$rows[0]."' data-page='footer' data-col='menu_right' class='type'>$rows[2]</td>
						<td ><button class='btn btn-danger bton' data-id='".$rows[0]."' data-page='footer' >x</button></td>
					</tr>
				
			";
			
		}
		
			$comment .="
				
					<tr>
						
						<td contenteditable id='menu'>$rows[1]</td>
						<td contenteditable id='menu_right'>$rows[2]</td>
						<td ><button class='btn btn-success ' id='addFooter' >+</button></td>
					</tr>
				
			";
	}
	else{
		$comment .="
				
					<tr>
						<td colspan='4'>Nothing Found</td>
					</tr>
				
			";
	}

	$comment .="</table></div>";
echo $comment;
}

/*This section is used to display and update POSTS as per the pages of website*/
else if($count==3){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM post;";

	$rs=mysql_query($query);

	$comment="";
	$comment .="
	
	<p style='text-align:justify; color:#33adff; font-weight:bold'>Here you can Add, Update or Delete POSTS. Please keep a track of which data you are deleting and inside which menu/submenu.<br/>
	* It is highly recommended to NOT TO CHANGE THE NAME OF MENU / SUBMENU.<br/>
	* If you change data in Menu / Submenu it might cause ron replication of data on the desired page</p>
	<br/>
	<table class='table-bordered table' >
	<tr style='background:#eee'>
						<th>Page Name</th>
						<th>Header</th>
						<th>Content</th>
						<th>Comment (This will not be shown to user)</th>
						<th>Delete/Add</th>
	</tr>

	";

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
				
					<tr >
						
						<td contenteditable data-id2='".$rows[1]."' data-page='post' data-col='pagename' data-id='".$rows[0]."' class='type'>$rows[1]</td>
						<td contenteditable data-id2='".$rows[2]."' data-page='post' data-col='header' data-id='".$rows[0]."' class='type'>$rows[2]</td>
						<td contenteditable data-id2='".$rows[3]."' data-page='post' data-col='content' data-id='".$rows[0]."' class='type'>$rows[3]</td>
						<td contenteditable data-id2='".$rows[4]."' data-page='post' data-col='comment' data-id='".$rows[0]."' class='type'>$rows[4]</td>
						<td ><button class='btn btn-danger bton' data-page='post' data-id='".$rows[0]."' >x</button></td>
					</tr>
				
			";
			
		}
		
			$comment .="
				
					<tr>
						
						<td contenteditable id='pagename'>$rows[1]</td>
						<td contenteditable id='header'>$rows[2]</td>
						<td class='txtEditor' id='content'>$rows[3]</td>
							<script>
									var editor = CKEDITOR.replace( 'content', {
										uiColor: '#ffffff',
									filebrowserBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html',
									filebrowserImageBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Images',
									filebrowserFlashBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Flash',
									filebrowserUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
									filebrowserImageUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
									filebrowserFlashUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'
								});
								CKFinder.setupCKEditor( editor, '../' );
							</script>
							
						<td contenteditable id='comment'>$rows[4]</td>
						<td ><button class='btn btn-success ' id='addPost' name='addPost' >+</button></td>
					</tr>
				
			";
	}
	else{
		$comment .="
				
					<tr>
						<td colspan='4'>Nothing Found</td>
					</tr>
				
			";
	}

	$comment .="</table></div>";
echo $comment;
}



/*This section is used to display add and update Users to D+ of website*/
else if($count==5){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM userallowed;";

	$rs=mysql_query($query);

	$comment="";
	$comment .="
	
	<p style='text-align:justify; color:#33adff; font-weight:bold'>
	Here you can Add, Update or Delete USERS who can see the D+ Posts.<br/>
	
	<table class='table-bordered table' >
	<tr style='background:#eee'>
						<th>User ID</th>
						<th>Coupon (to be used once per user)</th>
						<th>Date Added</th>
						<th>Added By</th>
						<th>Delete/Add</th>
	</tr>

	";

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
				
					<tr >
						<td data-id2='".$rows[1]."' data-page='userallowed' data-col='uid' data-id='".$rows[0]."' class='type'>$rows[1]</td>
						<td data-id2='".$rows[2]."' data-page='userallowed' data-col='coupon' data-id='".$rows[0]."' class='type'>$rows[2]</td>
						<td data-id2='".$rows[3]."' data-page='userallowed' data-col='dateAdded' data-id='".$rows[0]."' class='type'>$rows[3]</td>
						<td data-id2='".$rows[4]."' data-page='userallowed' data-col='addedBy' data-id='".$rows[0]."' class='type'>$rows[4]</td>
						<td ><button class='btn btn-danger bton' data-page='userallowed' data-id='".$rows[0]."' >x</button></td>
					</tr>
				
			";
			
		}
		
			$comment .="
				
					<tr>
						
						<td contenteditable id='uid' title='please do not add @cts.com, it will get auto populated'>$rows[1]</td>
						<td style='color:#808080'><i>The coupon code will be generated as soon as you add a user.<br/>
						This coupon needs to be used for one time by the user to confirm his/her authority to view page.<br/>
						Please donot add @cts.com, it will be auto populated</i></td>
						<td style='color:#808080'><i>This Field will be auto filled</i></td>
						<td style='color:#808080'><i>This Field will be auto filled</i></td>
						<td ><button class='btn btn-success ' id='addUser' name='addUser' >+</button></td>
					</tr>
				
			";
	}
	else{
		$comment .="
				
					<tr>
						<td colspan='4'>Nothing Found</td>
					</tr>
					<tr>
						
						<td contenteditable id='uid'>$rows[1]</td>
						<td style='color:#808080'><i>The coupon code will be generated as soon as you add a user.<br/>
						This coupon needs to be used for one time by the user to confirm his/her authority to view page.</i></td>
						<td style='color:#808080'><i>This Field will be auto filled</i></td>
						<td style='color:#808080'><i>This Field will be auto filled</i></td>
						<td ><button class='btn btn-success ' id='addUser' name='addUser' >+</button></td>
					</tr>
				
			";
	}

	$comment .="</table></div>";
echo $comment;
}


/*this section adds Admin to the portal*/
else if($count=='addAdmin'){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM adminuser;";

	$rs=mysql_query($query);

	$comment="";
	$comment .="
	
	<p style='text-align:justify; color:#33adff; font-weight:bold'>
	Here you can Add, Update or Delete ADMINS who can update the website.<br/>
	
	<table class='table-bordered table' >
	<tr style='background:#eee'>
						<th>User ID</th>
						<th>Coupon (to be used once per user)</th>
						<th>Date Added</th>
						<th>Added By</th>
						<th>Delete/Add</th>
	</tr>

	";

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
				
					<tr >
						<td data-id2='".$rows[1]."' data-page='adminuser' data-col='uid' data-id='".$rows[0]."' class='type'>$rows[1]</td>
						<td data-id2='".$rows[2]."' data-page='adminuser' data-col='coupon' data-id='".$rows[0]."' class='type'>$rows[2]</td>
						<td data-id2='".$rows[3]."' data-page='adminuser' data-col='dateAdded' data-id='".$rows[0]."' class='type'>$rows[3]</td>
						<td data-id2='".$rows[4]."' data-page='adminuser' data-col='addedBy' data-id='".$rows[0]."' class='type'>$rows[4]</td>
						<td ><button class='btn btn-danger bton' data-page='adminuser' data-id='".$rows[0]."' >x</button></td>
					</tr>
				
			";
			
		}
		
			$comment .="
				
					<tr>
						
						<td contenteditable id='uid' title='please do not add @cts.com, it will get auto populated'>$rows[1]</td>
						<td style='color:#808080'><i>The coupon code will be generated as soon as you add a user.<br/>
						This coupon needs to be used for one time by the user to confirm his/her authority to view page.<br/>
						Please donot add @cts.com, it will be auto populated</i></td>
						<td style='color:#808080'><i>This Field will be auto filled</i></td>
						<td style='color:#808080'><i>This Field will be auto filled</i></td>
						<td ><button class='btn btn-success ' id='addAdmin' name='addAdmin' >+</button></td>
					</tr>
				
			";
	}
	else{
		$comment .="
				
					<tr>
						<td colspan='4'>Nothing Found</td>
					</tr>
					<tr>
						
						<td contenteditable id='uid'></td>
						<td style='color:#808080'><i>The coupon code will be generated as soon as you add a user.<br/>
						This coupon needs to be used for one time by the user to confirm his/her authority to view page.</i></td>
						<td style='color:#808080'><i>This Field will be auto filled</i></td>
						<td style='color:#808080'><i>This Field will be auto filled</i></td>
						<td ><button class='btn btn-success ' id='addAdmin' name='addAdmin' >+</button></td>
					</tr>
				
			";
	}

	$comment .="</table></div>";
echo $comment;
}



else if($count==14){

	$con=mysql_connect("localhost","root","");
			mysql_select_db("counter",$con) or die (mysql_error());
			$query="SELECT * FROM user_data ORDER BY sno DESC;";
			$comment="";
		$comment.="<div style='padding-bottom:40px'>
					<p style='text-align:justify; color:#33adff; font-weight:bold'>Here you can see the visitor wise count as well as the last visit time</p>
					<table class='table-bordered table' >
					<tr style='background:#eee'>
										<th>S No.</th>
										<th>User ID</th>
										<th>Visit Count</th>
										<th>Last visited</th>
										
					</tr>";
					
			$rs=mysql_query($query);
			$count=1;
			while($rows=mysql_fetch_array($rs)){
				if ($count%2==1){
				$comment .="
				
					<tr >
						<td data-id2='".$rows[0]."' data-page='user_data' data-col='sno' data-id='".$rows[0]."' class='type'>$rows[0]</td>
						<td data-id2='".trim($rows[1],'@cts.com')."' data-page='user_data' data-col='userid' data-id='".$rows[0]."' class='type'>$rows[1]</td>
						<td data-id2='".$rows[2]."' data-page='user_data' data-col='visit_count' data-id='".$rows[0]."' class='type'>$rows[2]</td>
						<td data-id2='".$rows[3]."' data-page='user_data' data-col='last_visited' data-id='".$rows[0]."' class='type'>$rows[3]</td>
						
					</tr>
				
				";}else{
					$comment .="
				
					<tr style='background:#eee' >
						<td data-id2='".$rows[0]."' data-page='user_data' data-col='sno' data-id='".$rows[0]."' class='type'>$rows[0]</td>
						<td data-id2='".trim($rows[1],'@cts.com')."' data-page='user_data' data-col='userid' data-id='".$rows[0]."' class='type'>$rows[1]</td>
						<td data-id2='".$rows[2]."' data-page='user_data' data-col='visit_count' data-id='".$rows[0]."' class='type'>$rows[2]</td>
						<td data-id2='".$rows[3]."' data-page='user_data' data-col='last_visited' data-id='".$rows[0]."' class='type'>$rows[3]</td>
						
					</tr>
				
				";
				}
				$count++;
			}
			
	$comment .="</table></div>";
	
	
	$con=mysql_connect("localhost","root","");
	mysql_select_db("counter",$con) or die (mysql_error());
	$query="SELECT * FROM counter_table;";

	$rs=mysql_query($query);

	
	$comment .="
	
	<p style='text-align:justify; color:#33adff; font-weight:bold'>
	Here you can see hom many times the pages are hit. (this is not unique hit count, it is the total hit count.)<br/>
	</p>
	";

	
		while($row=mysql_fetch_array($rs))
		{
			$comment .="
				
					<li><strong>You are Visitor # <span style='color:#ff6d06'>$row[1]</span></strong></li>
					<li><strong>Home Page Visitor # <span style='color:#ff6d06'>$row[2]</span></strong></li>
					<li><strong>RCG At A Glance Visitor # <span style='color:#ff6d06'>$row[3]</span></strong></li>
					<li><strong>Supply Chain Management Visitor # <span style='color:#ff6d06'>$row[4]</span></strong></li>
					<li><strong>Store Operation Visitor # <span style='color:#ff6d06'>$row[5]</span></strong></li>
					<li><strong>Digital Commerce Visitor # <span style='color:#ff6d06'>$row[6]</span></strong></li>
					<li><strong>Order Management Visitor # <span style='color:#ff6d06'>$row[7]</span></strong></li>
					<li><strong>Merchandising & Planning Visitor # <span style='color:#ff6d06'>$row[8]</span></strong></li>
					<li><strong>Enterprise Application Visitor # <span style='color:#ff6d06'>$row[9]</span></strong></li>
					<li><strong>Case Study Visitor # <span style='color:#ff6d06'>$row[10]</span></strong></li>
					<li><strong>Bug Bank Visitor # <span style='color:#ff6d06'>$row[11]</span></strong></li>
					<li><strong>Scenario Repository Visitor # <span style='color:#ff6d06'>$row[12]</span></strong></li>
					<li><strong>Flow Diagram Visitor # <span style='color:#ff6d06'>$row[13]</span></strong></li>
					<li><strong>Templates Visitor # <span style='color:#ff6d06'>$row[14]</span></strong></li>
					<li><strong>Knowledge Repository Visitor # <span style='color:#ff6d06'>$row[15]</span></strong></li>
					<li><strong>Automation Framework Visitor # <span style='color:#ff6d06'>$row[16]</span></strong></li>
					<li><strong>Innovation Visitor # <span style='color:#ff6d06'>$row[17]</span></strong></li>
					<li><strong>Compitancy Building Visitor # <span style='color:#ff6d06'>$row[18]</span></strong></li>
					<li><strong>Contact Us Visitor # <span style='color:#ff6d06'>$row[19]</span></strong></li>
					<li><strong>Site Map Visitor # <span style='color:#ff6d06'>$row[20]</span></strong></li>
					
					
					
				
			";
		}
		
echo $comment;
}

/*This section is used to display and update Welcome Message as per the pages of website*/
else if($count=='welcomeMsg'){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM welcome;";

	$rs=mysql_query($query);

	$comment="";
	$comment .="
	
	<p style='text-align:justify; color:#33adff; font-weight:bold'>Here you can Add, Update or Delete WELCOME PAGE MODAL<br/>
	* Only one welcome message could be palced. Whenever you add a new welcome message.. the old one will be auto deleted
	<br/>
	<table class='table-bordered table' >
	<tr style='background:#eee'>
						<th>Modal Body</th>
						<th>Delete/Add</th>
	</tr>

	";

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
				
					<tr >
						
						<td data-id2='".$rows[1]."' data-page='welcome' data-col='body' data-id='".$rows[0]."' class='type'>$rows[1]</td>
						<td ><button class='btn btn-danger bton' data-page='welcome' data-id='".$rows[0]."' >x</button></td>
					</tr>
				
			";
			
		}
		
			$comment .="
				
					<tr>
						
					
						<td class='txtEditor' id='body'>$rows[1]</td>
							<script>
									var editor = CKEDITOR.replace( 'body', {
										uiColor: '#ffffff',
									filebrowserBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html',
									filebrowserImageBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Images',
									filebrowserFlashBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Flash',
									filebrowserUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
									filebrowserImageUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
									filebrowserFlashUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'
								});
								CKFinder.setupCKEditor( editor, '../' );
							</script>
						<td ><button class='btn btn-success ' id='updateWelcomeMsg' name='updateWelcomeMsg' >+</button></td>
					</tr>
				
			";
	}
	else{
		$comment .="
				
					<tr>
						<td colspan='4'>Nothing Found</td>
					</tr>
					<tr>
						
					
						<td class='txtEditor' id='body'></td>
							<script>
									var editor = CKEDITOR.replace( 'body', {
										uiColor: '#ffffff',
									filebrowserBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html',
									filebrowserImageBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Images',
									filebrowserFlashBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Flash',
									filebrowserUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
									filebrowserImageUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
									filebrowserFlashUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'
								});
								CKFinder.setupCKEditor( editor, '../' );
							</script>
						<td ><button class='btn btn-success ' id='updateWelcomeMsg' name='updateWelcomeMsg' >+</button></td>
					</tr>
				
			";
	}

	$comment .="</table></div>";
echo $comment;
}

/*This section is used to display and update Side - Nav as per the pages of website*/
else if($count=='sideNav'){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM sidnav;";

	$rs=mysql_query($query);

	$comment="";
	$comment .="
	
	<p style='text-align:justify; color:#33adff; font-weight:bold'>Here you can Add, Update or Delete side navigations on the page<br/>
	* Please provide the exact page name as mentioned in the menubar, and change the visibility to true, else the menu will not be visible on the page.
	<br/>
	<table class='table-bordered table' >
	<tr style='background:#eee'>
						<th>Page Name</th>
						<th>Side Nav</th>
						<th>Description</th>
						<th>Side Active / Deactive</th>
						<th>Delete/Add</th>
	</tr>

	";

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
				
					<tr >
						<td contenteditable data-id2='".$rows[1]."' data-page='sidnav' data-col='pagename' data-id='".$rows[0]."' class='type'>$rows[1]</td>
						<td contenteditable data-id2='".$rows[2]."' data-page='sidnav' data-col='nav' data-id='".$rows[0]."' class='type'>$rows[2]</td>
						<td contenteditable data-id2='".$rows[3]."' data-page='sidnav' data-col='description' data-id='".$rows[0]."' class='type'>$rows[3]</td>
						<td contenteditable data-id2='".$rows[4]."' data-page='sidnav' data-col='active' data-id='".$rows[0]."' class='type'>$rows[4]</td>
						<td ><button class='btn btn-danger bton' data-page='sidnav' data-id='".$rows[0]."' >x</button></td>
						
					</tr>
				
			";
			
		}
		
			$comment .="
				
					<tr>
						
						<td contenteditable data-page='sidnav' id='pagename'>$rows[1]</td>
						<td contenteditable data-page='sidnav' id='nav'>$rows[2]</td>
						<td contenteditable data-page='sidnav' id='description'>$rows[3]</td>
						<script>
									var editor = CKEDITOR.replace( 'description', {
										uiColor: '#ffffff',
									filebrowserBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html',
									filebrowserImageBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Images',
									filebrowserFlashBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Flash',
									filebrowserUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
									filebrowserImageUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
									filebrowserFlashUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'
								});
								CKFinder.setupCKEditor( editor, '../' );
							</script>
						<td contenteditable data-page='sidnav' id='active'>$rows[4]</td>
						<td ><button class='btn btn-success ' data-page='sidnav' id='addsidenav' >+</button></td>
					</tr>
				
			";
	}
	else{
		$comment .="
				
					<tr>
						<td colspan='4'>Nothing Found</td>
					</tr>
					<tr>
						
					
						<td class='txtEditor' id='body'></td>
						<script>
									var editor = CKEDITOR.replace( 'body', {
										uiColor: '#ffffff',
									filebrowserBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html',
									filebrowserImageBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Images',
									filebrowserFlashBrowseUrl : '../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Flash',
									filebrowserUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
									filebrowserImageUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
									filebrowserFlashUploadUrl : '../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'
								});
								CKFinder.setupCKEditor( editor, '../' );
							</script>
						<td ><button class='btn btn-success ' id='addsidenav' name='addsidenav' >+</button></td>
					</tr>
				
			";
	}

	$comment .="</table></div>";
echo $comment;
}


/*This section is used to display and update website logo as per the pages of website*/
else if($count=='uploadLogo'){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="select * from up_fs ORDER BY fileid DESC LIMIT 1;";

	$rs=mysql_query($query);

	$comment="";
	$comment .="
	
	<p style='text-align:justify; color:#33adff; font-weight:bold'>Here you can Update the website logo..<br/>Please keep in mind that this logo will appear throughout the website</p>
	

	";

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="<h2>This is the current logo for the website</h2>
					<img style='max-height:200px; max-width:150px' src='$rows[4]'><br/>
					<h2>Upload new Logo</h2>
					<form method='post' action='Ajaxupload.php' enctype='multipart/form-data'>
					select a file to upload
					<input type='file' accept='image/*' name='myfile' id='myfile' />
					<br />
					<input type='submit' name='upload' id='upload' value='upload' />
					</form>
					";			
		}
	}
	
	
echo $comment;
}



/*This section is used to display and update website logo as per the pages of website*/
else if($count=='uploadApp'){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="select * from up_app ORDER BY fileid DESC LIMIT 1;";

	$rs=mysql_query($query);

	$comment="";
	$comment .="
	
	
	<p style='text-align:justify; color:#33adff; font-weight:bold'>Here you can Update the website App to its newest version..<br/>Please keep in mind that this App will be availabe for download on the website</p>
	

	";

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="<h2>This is the current App for the website</h2>
					Latest App Download Here -> <a href='$rows[4]'>App Name -> <span style='color:#ff6d06; font-weight:bold' >$rows[1]</font></a><br/>
					<h2>Upload new App</h2>
					<form method='post' action='appUploader.php' enctype='multipart/form-data'>
					Select app file to upload (.apk file)
					<input type='file' name='myfile' id='myfile' />
					<br />
					<input type='submit' name='uploadApp' id='uploadApp' value='upload' />
					</form>
					";			
		}
	}
	
	
echo $comment;
}


/*This section is used to display and update Marquee as per the pages of website*/
else if($count=='marquee'){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM marquee;";

	$rs=mysql_query($query);

	$comment="";
	$comment .="
	
	<p style='text-align:justify; color:#33adff; font-weight:bold'>Here you can Add, Update or Delete marquee details on the page<br/>
	* Please provide the exact page name as mentioned in the menubar, and change the visibility to true, else the menu will not be visible on the page.
	<br/>
	<table class='table-bordered table' >
	<tr style='background:#eee'>
						<th>Page Name</th>
						<th>File Type</th>
						<th>File Size</th>
						<th>Title of the Marqee</th>
						<th>File Link (This will be auto generated)</th>
						<th>Delete/Add</th>
	</tr>

	";

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
				
					<tr >
						<td contenteditable data-id2='".$rows[1]."' data-page='marquee' data-col='pagename' data-id='".$rows[0]."' class='type'>$rows[1]</td>
						<td  data-id2='".$rows[2]."' data-page='marquee' data-col='filetype' data-id='".$rows[0]."' class='type'>$rows[2]</td>
						<td  data-id2='".$rows[3]."' data-page='marquee' data-col='filesize' data-id='".$rows[0]."' class='type'>$rows[3] Byte</td>
						<td contenteditable data-id2='".$rows[4]."' data-page='marquee' data-col='title' data-id='".$rows[0]."' class='type'>$rows[4]</td>
						<td data-id2='".$rows[5]."' data-page='marquee' data-col='link' data-id='".$rows[0]."' id='myfile' class='type'>$rows[5]</td>
						<td ><button class='btn btn-danger bton' data-page='marquee' data-id='".$rows[0]."' >x</button></td>
						
					</tr>
				
			";
			
		}
		$comment .="</table></div>";
			$comment .='
				
				
						<form  method="post" role="form" enctype="multipart/form-data"  action="marqueeDataUpload.php">
						<input type="text" class="form-control" required="required" placeholder="page name" id="pagename" name="pagename" style="max-width:25%; display:inline">
						<input type="text" class="form-control" required="required" placeholder="title to be shown to user" id="title" name="title" style="max-width:25%; display:inline">
						<input type="file" name="myfile" id="myfile" class="form-control" required="required" style="max-width:25%; display:inline">
						<input type="submit" id="uploadMarquueeData" name="uploadMarquueeData" class="btn btn-success" align="right" value="+" />
						</form>
					
				
				
			';
	}
	

	
echo $comment;
}


/*This section is used to display and update Header Image as per the pages of website*/
else if($count=='headerImage'){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM headerimage;";

	$rs=mysql_query($query);

	$comment="";
	$comment .="
	
	<p style='text-align:justify; color:#33adff; font-weight:bold'>Here you can Add, Update or Delete Header Image details on the page<br/>
	* Please provide the exact page name as mentioned in the menubar, else the menu will not be visible on the page.
	<br/>
	<table class='table-bordered table' >
	<tr style='background:#eee'>
						<th>Page Name</th>
						<th>File Type</th>
						<th>File Size</th>
						<th>Comments (this will not be displayed)</th>
						<th>File Link (This will be auto generated)</th>
						<th>Delete/Add</th>
	</tr>

	";

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
				
					<tr >
						<td contenteditable data-id2='".$rows[1]."' data-page='headerimage' data-col='pagename' data-id='".$rows[0]."' class='type'>$rows[1]</td>
						<td  data-id2='".$rows[2]."' data-page='headerimage' data-col='filetype' data-id='".$rows[0]."' class='type'>$rows[2]</td>
						<td  data-id2='".$rows[3]."' data-page='headerimage' data-col='filesize' data-id='".$rows[0]."' class='type'>$rows[3] Byte</td>
						<td contenteditable data-id2='".$rows[4]."' data-page='headerimage' data-col='title' data-id='".$rows[0]."' class='type'>$rows[4]</td>
						<td><img src='$rows[5]' class='img-responsive' style='max-height:200px; max-width:650px;'/></td>
						<td ><button class='btn btn-danger bton' data-page='headerimage' data-id='".$rows[0]."' >x</button></td>
						
					</tr>
				
			";
			
		}
		$comment .="</table></div>";
		
			$comment .='
				
				
						<form  method="post" role="form" enctype="multipart/form-data"  action="headerImageUpload.php">
						<input type="text" class="form-control" required="required" placeholder="Page Name" id="pagename" name="pagename" style="max-width:25%; display:inline">
						<input type="text" class="form-control" required="required" placeholder="Comments for reference, will not be shown to user" id="title" name="title" style="max-width:30%; display:inline">
						<input type="file" name="myfile" id="myfile" class="form-control" required="required" style="max-width:25%; display:inline">
						<input type="submit" id="uploadMarquueeData" name="uploadMarquueeData" class="btn btn-success" align="right" value="+" />
						</form>
					
				
				
			';
	}
	

	
echo $comment;
}



/*This section is used to display and update Intro part as per the pages of website*/
else if($count=='intro'){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM intro;";

	$rs=mysql_query($query);

	$comment="";
	$comment .="
	
	<p style='text-align:justify; color:#33adff; font-weight:bold'>Here you can Add, Update or Delete Intro Part of each page<br/>
	* Please provide the exact page name as mentioned in the menubar, else the intro will not be visible on the page.
	<br/>
	<table class='table-bordered table' >
	<tr style='background:#eee'>
						<th>Page Name</th>
						<th>File Type</th>
						<th>File Size</th>
						<th>Comments (this will not be displayed)</th>
						<th>File Link (This will be auto generated)</th>
						<th>Delete/Add</th>
	</tr>

	";

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
				
					<tr >
						<td contenteditable data-id2='".$rows[1]."' data-page='intro' data-col='pagename' data-id='".$rows[0]."' class='type'>$rows[1]</td>
						<td  data-id2='".$rows[2]."' data-page='intro' data-col='filetype' data-id='".$rows[0]."' class='type'>$rows[2]</td>
						<td  data-id2='".$rows[3]."' data-page='intro' data-col='filesize' data-id='".$rows[0]."' class='type'>$rows[3] Byte</td>
						<td contenteditable data-id2='".$rows[4]."' data-page='intro' data-col='title' data-id='".$rows[0]."' class='type'>$rows[4]</td>
						<td><img src='$rows[5]' class='img-responsive' style='max-height:200px; max-width:650px;'/></td>
						<td ><button class='btn btn-danger bton' data-page='intro' data-id='".$rows[0]."' >x</button></td>
						
					</tr>
				
			";
			
		}
		$comment .="</table></div>";
		
			$comment .='
				
				
						<form  method="post" role="form" enctype="multipart/form-data" action="javascript:;">
						<input type="text" class="form-control" placeholder="Page Name" id="pagename" name="pagename" style="max-width:25%; display:inline" />
						<input type="file" name="file" id="file" class="form-control"  style="max-width:25%; display:inline"/>
						<input type="text" class="form-control" id="body"  placeholder="Summery Part.. Please make it crisp" style="max-width:30%; display:inline" />
							<script>
									var editor = CKEDITOR.replace( "body", {
										uiColor: "#ffffff",
									filebrowserBrowseUrl : "../ckeditor-ckfinder-integration/ckfinder/ckfinder.html",
									filebrowserImageBrowseUrl : "../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Images",
									filebrowserFlashBrowseUrl : "../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Flash",
									filebrowserUploadUrl : "../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files",
									filebrowserImageUploadUrl : "../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images",
									filebrowserFlashUploadUrl : "../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash"
								});
								CKFinder.setupCKEditor( editor, "../" );
							</script>
						
						<input type="submit" id="introDataUpload" name="introDataUpload" class="btn btn-success" align="right" value="+" />
						</form>
					
				
				
			';
	}
	

	
echo $comment;
}


/*This section is used to display and update Our Assets part as per the pages of website*/
else if($count=='ourAsset'){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM assets;";
	$rs=mysql_query($query);
	$comment="";
	$comment .="
	
	<p style='text-align:justify; color:#33adff; font-weight:bold'>Here you can Add, Update or Delete assets Part of each page<br/>
	* Please provide the exact page name as mentioned in the menubar, else the assets will not be visible on the page.
	<br/>
	<table class='table-bordered table' >
	<tr style='background:#eee'>
						<th>Page Name</th>
						<th>Asset Name</th>
						<th>Asset Image</th>
						<th>Asset Content</th>
						<th>Link</th>
						<th>Delete/Add</th>
	</tr>

	";

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
				
					<tr >
						<td contenteditable data-id2='".$rows[1]."' data-page='assets' data-col='pagename' data-id='".$rows[0]."' class='type'>$rows[1]</td>
						<td contenteditable data-id2='".$rows[2]."' data-page='assets' data-col='asset_name' data-id='".$rows[0]."' class='type'>$rows[2]</td>
						<td><img src='$rows[3]' data-id2='".$rows[3]."' data-page='assets' data-col='asset_image' data-id='".$rows[0]."' style='max-height:100px;' class='type'/></td>
						<td contenteditable data-id2='".$rows[4]."' data-page='assets' data-col='asset_content' data-id='".$rows[0]."' class='type'>$rows[4]</td>
						<td contenteditable data-id2='".$rows[5]."' data-page='assets' data-col='link' data-id='".$rows[0]."' class='type'><a href='$rows[5]'>$rows[5]</a></td>
						<td ><button class='btn btn-danger bton' data-page='assets' data-id='".$rows[0]."' >x</button></td>
						
					</tr>
				
			";
			
		}
		$comment .="</table></div>";
		
			$comment .='
				
				
						<form  method="post" role="form" enctype="multipart/form-data"  action="javascript:;">
						<input type="text" class="form-control" placeholder="Page Name" id="pagename" name="pagename" style="max-width:23%; display:inline" />
						<input type="text" class="form-control" placeholder="Asset Name" id="asset_name" name="asset_name" style="max-width:23%; display:inline" />
						<input type="text" class="form-control" placeholder="Asset Link" id="asset_link" name="asset_link" style="max-width:23%; display:inline" />
						<input type="file" name="file" id="file" class="form-control"  style="max-width:25%; display:inline"/>
						<input type="text" class="form-control txtEditor"  placeholder="Summery Part.. Please make it crisp" id="asset_content" name="asset_content" style="max-width:30%; display:inline" />
							<script>
									var editor = CKEDITOR.replace( "asset_content", {
										uiColor: "#ffffff",
									filebrowserBrowseUrl : "../ckeditor-ckfinder-integration/ckfinder/ckfinder.html",
									filebrowserImageBrowseUrl : "../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Images",
									filebrowserFlashBrowseUrl : "../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Flash",
									filebrowserUploadUrl : "../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files",
									filebrowserImageUploadUrl : "../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images",
									filebrowserFlashUploadUrl : "../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash"
								});
								CKFinder.setupCKEditor( editor, "../" );
							</script>
						
						<input type="submit" id="assetsDataUpload" name="assetsDataUpload" class="btn btn-success" align="right" value="+" />
						</form>
					
				
				
			';
	}
	

	
echo $comment;
}



/*This section is used to display and update Our Post Read More part as per the pages of website*/
else if($count=='readMorePosts'){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM post_read_more;";

	$rs=mysql_query($query);

	$comment="";
	$comment .="
	
	<p style='text-align:justify; color:#33adff; font-weight:bold'>Here you can Add, Update or Delete readMorePosts Part of each page<br/>
	* Please provide the exact page name as mentioned in the menubar, else the readMorePosts will not be visible on the page.
	<br/>
	<table class='table-bordered table' >
	<tr style='background:#eee'>
						<th>Page Name</th>
						<th>Post Header</th>
						<th>Text(to be shown to user)</th>
						<th>File Name</th>
						<th>Delete/Add</th>
	</tr>

	";

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
				
					<tr >
						<td contenteditable data-id2='".$rows[1]."' data-page='post_read_more' data-col='pagename' data-id='".$rows[0]."' class='type'>$rows[1]</td>
						<td contenteditable data-id2='".$rows[2]."' data-page='post_read_more' data-col='header' data-id='".$rows[0]."' class='type'>$rows[2]</td>
						<td contenteditable data-id2='".$rows[3]."' data-page='post_read_more' data-col='text' data-id='".$rows[0]."' class='type'>$rows[3] Byte</td>
						<td  data-id2='".$rows[4]."' data-page='post_read_more' data-col='link' data-id='".$rows[0]."' class='type'>$rows[4]</td>
						<td ><button class='btn btn-danger bton' data-page='post_read_more' data-id='".$rows[0]."' >x</button></td>
						
					</tr>
				
			";
			
		}
		$comment .="</table></div>";
		
			$comment .='
				
				
						<form  method="post" role="form" enctype="multipart/form-data"  action="javascript:;">
						<input type="text" class="form-control" placeholder="Page Name" id="pagename" name="pagename" style="max-width:25%; display:inline" />
						<input type="text" class="form-control" placeholder="Page Header" id="header" name="header" style="max-width:25%; display:inline" />
						<input type="text" class="form-control"  placeholder="Summery Part.. Please make it crisp" id="body" name="body" style="max-width:30%; display:inline" />
							<script>
									var editor = CKEDITOR.replace( "body", {
										uiColor: "#ffffff",
									filebrowserBrowseUrl : "../ckeditor-ckfinder-integration/ckfinder/ckfinder.html",
									filebrowserImageBrowseUrl : "../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Images",
									filebrowserFlashBrowseUrl : "../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Flash",
									filebrowserUploadUrl : "../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files",
									filebrowserImageUploadUrl : "../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images",
									filebrowserFlashUploadUrl : "../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash"
								});
								CKFinder.setupCKEditor( editor, "../" );
							</script>
						<input type="file" name="file" id="file" class="form-control"  style="max-width:25%; display:inline"/>
						<input type="submit" id="RMPData" name="RMPData" class="btn btn-success" align="right" value="+" />
						</form>
					
				
				
			';
	}
	

	
echo $comment;
}


/*This section is used to display and update Modal Menu part as per the pages of website*/
else if($count=='modalMenu'){
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$query="SELECT * FROM modalmenu;";

	$rs=mysql_query($query);

	$comment="";
	$comment .='
	
	<p style="text-align:justify; color:#33adff; font-weight:bold">Here you can Add, Update or Delete Modal Menu Part of each page<br/>
	* Please provide the exact page name as mentioned in the menubar, else the Modal Menu will not be visible on the page.
	<br/></p>
	<div class="row">
						<div class="col-sm-6" style="color:#808080">
						<p>The logo will be displayed as per the name of menu. Please have a note of the menus defined below for name reference.</p>
						<ul>
							<li>Use " Accelerator " for <img src="../logoForModal/Accelerator.png"</li>
							<li>Use " Automation " for <img src="../logoForModal/Automation.png"</li>
							<li>Use " Best Practices " for <img src="../logoForModal/Best Practices.png"</li>
							<li>Use " Biz Dev " for <img src="../logoForModal/Biz Dev.png"</li>
							<li>Use " Case Study " for <img src="../logoForModal/Case Study.png"</li>
							
						</ul>
						</div>
						
						<div class="col-sm-6" style="color:#808080">
						<p>&ensp;<br/>&ensp;</p>
						<ul>
							
							<li>Use " E2E " for <img src="../logoForModal/E2E.png"</li>
							<li>Use " Estimation " for <img src="../logoForModal/Estimation.png"</li>
							<li>Use " Knowledge Repository " for <img src="../logoForModal/Knowledge Repository.png"</li>
							<li>Use " Success Story " for <img src="../logoForModal/Success Story.png"</li>
							<li>Use " Test Plan " for <img src="../logoForModal/Test Plan.png"</li>
						</ul>
						</div>
						</div>
						
	<table class="table-bordered table" >
	<tr style="background:#eee">
						<th>Page Name</th>
						<th>Side Nav</th>
						<th>Menu Name</th>
						<th>Menu Logo</th>
						<th>Content</th>
						<th>Read More Document</th>
						<th>Delete/Add</th>
	</tr>

	';

	if (mysql_num_rows($rs))
	{
		while($rows=mysql_fetch_array($rs))
		{
			$comment .="
				
					<tr >
						<td contenteditable data-id2='".$rows[1]."' data-page='modalmenu' data-col='pagename' data-id='".$rows[0]."' class='type'>$rows[1]</td>
						<td contenteditable data-id2='".$rows[2]."' data-page='modalmenu' data-col='nav' data-id='".$rows[0]."' class='type'>$rows[2]</td>
						<td contenteditable data-id2='".$rows[3]."' data-page='modalmenu' data-col='menuname' data-id='".$rows[0]."' class='type'>$rows[3] </td>
						<td> <img src='../logoForModal/".$rows[3].".png' data-id2='".$rows[4]."' data-page='modalmenu' data-col='menulogo' data-id='".$rows[0]."' class='type'/></td>
						<td contenteditable data-id2='".$rows[5]."' data-page='modalmenu' data-col='content' data-id='".$rows[0]."' class='type'>$rows[5] </td>
						<td data-id2='".$rows[6]."' data-page='modalmenu' data-col='readmore' data-id='".$rows[0]."' class='type'>$rows[6] </td>
						<td ><button class='btn btn-danger bton' data-page='modalmenu' data-id='".$rows[0]."' >x</button></td>
						
					</tr>
				
			";
			
		}
		$comment .="</table>";
		
			$comment .='
						
						<form  method="post" role="form" enctype="multipart/form-data"  action="javascript:;">
						<input type="text" class="form-control" placeholder="Page Name" id="pagename" name="pagename" style="max-width:25%; display:inline" required/>
						<input type="text" class="form-control" placeholder="Nav Name" id="nav" name="nav" style="max-width:25%; display:inline" required/>
						<input type="text" class="form-control" placeholder="Menu Name" id="menuname" name="menuname" style="max-width:25%; display:inline" required/>
						<input type="text" class="form-control"  placeholder="Summery Part.. Please make it crisp" id="content" name="content" style="max-width:30%; display:inline" />
						<input type="file" name="file" id="file" title="Document to be shown" class="form-control"  style="max-width:25%; display:inline"/>
							<script>
									var editor = CKEDITOR.replace( "content", {
									uiColor: "#ffffff",
									filebrowserBrowseUrl : "../ckeditor-ckfinder-integration/ckfinder/ckfinder.html",
									filebrowserImageBrowseUrl : "../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Images",
									filebrowserFlashBrowseUrl : "../ckeditor-ckfinder-integration/ckfinder/ckfinder.html?type=Flash",
									filebrowserUploadUrl : "../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files",
									filebrowserImageUploadUrl : "../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images",
									filebrowserFlashUploadUrl : "../ckeditor-ckfinder-integration/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash"
								});
								CKFinder.setupCKEditor( editor, "../" );
							</script>
						
						<input type="submit" id="modalMenu" name="modalMenu" class="btn btn-success" align="right" value="+" />
						</form>
			';
	}
	

	
echo $comment;
}



}else die();
?>
