<?php
/*This file is used to delete data from table, please make sure that the database name, host name, username, password, table name, and column names are as per mentioned in the codes*/
  $id=$_POST['id'];
 $table=$_POST['table'];


$con=mysql_connect("localhost","root","");
mysql_select_db("rcg_db",$con) or die (mysql_error());

$query="Delete from ".$table." where sno='".$id."';";

if(mysql_query($query))
{
	echo"Deleted! Please wait while the page gets reloaded with updated data.";
}

?>