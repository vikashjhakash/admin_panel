<p>welcome to the admin panel, You are at the home page</p>
<p>Please select any of the menu to update the website</p>