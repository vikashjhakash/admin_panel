<?php

$pagename='';
$title='';
$pagename=$_POST['pagename'];
$title=$_POST['title'];
	
$error=$_FILES['file']['error'];
	if($error!=0)
	{
	echo "File not uploaded, it seems the file is not selected or there is some error with the file or the server seems busy, try later.
	We will redirect you back to the dashboard. Please wait..";
	}
	else
	{
	$fname=$_FILES['file']['name'];
	$ftype=$_FILES['file']['type'];
	$fsize=$_FILES['file']['size'];
	$ftname=$_FILES['file']['tmp_name'];
	$target="../intro/$fname";
	
	$ans=move_uploaded_file($ftname,$target);
	if($ans)
	{
	//save info to database
	$con=mysql_connect("localhost","root","");
	mysql_select_db("rcg_db",$con) or die (mysql_error());
	$target=addslashes($target);
		
		$query="insert into intro (pagename,filetype,filesize,title,link) values ('$pagename','$ftype',$fsize,'$title','$target')";
		$n=mysql_query($query);
		
		if($n==1)
		{
			echo "File upload successful";
			
		}
		else
		{
		echo "File not uploaded, server seems busy, try later. We will redirect you back to the dashboard. Please wait..";
		
		}
	}
	else
	{
	echo "File not uploaded, server seems busy, try later. We will redirect you back to the dashboard. Please wait.";
			
	}
	
	}

?>